<?php
/**
 * @package     TJCertificate
 * @subpackage  com_tjcertificate
 *
 * @author      Techjoomla <extensions@techjoomla.com>
 * @copyright   Copyright (C) 2009 - 2019 Techjoomla. All rights reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;

?>
<form action="<?php echo Route::_('index.php?option=com_tjcertificate&view=certificate'); ?>" method="post" name="adminForm" id="adminForm">
	<div class="btn-wrapper input-append">
		<input type="text" name="certificate" id="certificate"
		value="<?php echo $this->uniqueCertificateId; ?>" placeholder="Enter Certificate Id">
		<button type="submit" class="btn hasTooltip" title="" aria-label="Search" data-original-title="Search">
			<span class="icon-search" aria-hidden="true"></span>
		</button>
	</div>
</form>

<?php
if ($this->certificate)
{
?>
<div class="techjoomla-bootstrap">
	<div class="table-responsive">
		<table cellpadding="5">
			<tr>
				<td>
					<input type="button" class="btn btn-blue" onclick="printCertificate('certificateContent')"
					value="<?php echo Text::_('COM_TJCERTIFICATE_CERTIFICATE_PRINT');?>" />
				</td>
				<?php
				if ($this->certificate->getDownloadUrl())
				{
					?>
					<td>
						<a class="btn btn-primary btn-medium" href="<?php echo $this->certificate->getDownloadUrl();?>">
							<?php
								echo Text::_('COM_TJCERTIFICATE_CERTIFICATE_DOWNLOAD_PDF');
							?>
						</a>
					</td>
					<?php
				}
				?>
			</tr>
		</table>
	</div>
<div>

<div id="certificateContent">
<?php
	echo $this->certificate->generated_body;
?>
</div>
<?php
}
?>

<script type="text/javascript">
function printCertificate(elementId) {
	var printContent        = document.getElementById(elementId).innerHTML;
	var originalContent     = document.body.innerHTML;
	document.body.innerHTML = printContent;
	window.print();
	document.body.innerHTML = originalContent;
}
</script>
